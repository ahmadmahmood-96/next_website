import FiveLostPrinciples from "./components/FiveLostPrinciples";
import HeroComponent from "./components/HeroComponent";
import MyObjective from "./components/MyObjective";
import Navbar from "./components/Navbar";

export default function Home() {
  return (
    <>
    <Navbar />
    <HeroComponent/>    
    <FiveLostPrinciples/>
    <MyObjective/>
    </>
  );
}
